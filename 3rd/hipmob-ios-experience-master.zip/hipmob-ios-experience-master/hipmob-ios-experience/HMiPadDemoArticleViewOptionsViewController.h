//
//  HMiPhoneDemoArticleViewOptionsViewController.h
//  hipmob-ios-experience
//
//  Created by Olufemi Omojola on 1/8/14.
//  Copyright (c) 2014 Orthogonal Labs, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMiPadDemoArticleViewOptionsViewController : UITableViewController

@end
