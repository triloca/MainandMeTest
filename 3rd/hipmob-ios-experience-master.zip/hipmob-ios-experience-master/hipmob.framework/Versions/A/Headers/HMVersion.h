//
//  HMVersion.h
//  hipmob
//
//  Created by Olufemi Omojola on 7/10/13.
//  Copyright (c) 2013-2015 Orthogonal Labs, Inc. All rights reserved.
//

#ifndef hipmob_HMVersion_h
#define hipmob_HMVersion_h

#define HIPMOB_LIBRARY_VERSION              3.9.9
#define HIPMOB_LIBRARY_VERSION_STRING       @"3.9.9"

#endif
