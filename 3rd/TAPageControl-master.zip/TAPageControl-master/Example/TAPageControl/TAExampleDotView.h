//
//  TAExampleDotView.h
//  TAPageControl
//
//  Created by Tanguy Aladenise on 2015-01-23.
//  Copyright (c) 2015 Tanguy Aladenise. All rights reserved.
//

#import "TAAbstractDotView.h"

@interface TAExampleDotView : TAAbstractDotView

@end
