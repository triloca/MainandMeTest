//
//  AFBFriendsViewController.h
//  AllComponents
//
//  Created by Sasha on 4/27/14.
//  Copyright (c) 2014 uniprog. All rights reserved.
//


@interface AFBFriendsViewController : UIViewController

@end
