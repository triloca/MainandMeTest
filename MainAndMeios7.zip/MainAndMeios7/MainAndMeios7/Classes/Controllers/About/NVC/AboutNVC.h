//
//  AboutNVC.h
//  MainAndMeios7
//
//  Created by Max on 11/7/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutNVC : UINavigationController

@end
