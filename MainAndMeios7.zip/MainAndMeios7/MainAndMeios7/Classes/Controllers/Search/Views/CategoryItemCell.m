//
//  CategoryItemCell.m
//  MainAndMeios7
//
//  Created by Alexander Bukov on 11/3/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import "CategoryItemCell.h"

@interface CategoryItemCell ()


@end

@implementation CategoryItemCell



- (void)awakeFromNib{
    [super awakeFromNib];
    
    self.layer.cornerRadius = 4;
    self.clipsToBounds = YES;
}







@end
