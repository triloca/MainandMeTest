//
//  CoverView.h
//  MainAndMeios7
//
//  Created by Alexander Bukov on 4/23/15.
//  Copyright (c) 2015 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoverView : UIView

@end
