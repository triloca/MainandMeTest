//
//  ForgetPasswordVC.h
//  MainAndMeios7
//
//  Created by apple n berry on 12/11/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgetPasswordVC : UIViewController
{
    
}

@end
