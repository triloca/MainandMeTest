//
//  PlacesFollowNVC.m
//  MainAndMeios7
//
//  Created by Max on 11/8/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import "PlacesFollowNVC.h"
#import "UIViewController+ECSlidingViewController.h"

@interface PlacesFollowNVC ()

@end

@implementation PlacesFollowNVC
//Code moved to BaseNavigationController
@end
