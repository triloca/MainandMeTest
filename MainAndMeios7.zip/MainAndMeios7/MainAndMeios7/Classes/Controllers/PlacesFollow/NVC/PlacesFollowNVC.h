//
//  PlacesFollowNVC.h
//  MainAndMeios7
//
//  Created by Max on 11/8/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseNavigationController.h"

@interface PlacesFollowNVC : BaseNavigationController

@end
