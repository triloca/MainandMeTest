//
//  ItemStoreVC.h
//  MainAndMeios7
//
//  Created by Alexander Bukov on 10/19/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemStoreVC : UIViewController
@property (strong, nonatomic) NSDictionary* category;
@property (assign, nonatomic) BOOL isAllCategories;
@end
