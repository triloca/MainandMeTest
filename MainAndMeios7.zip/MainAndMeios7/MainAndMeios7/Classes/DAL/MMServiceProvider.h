//
//  MMServiceProvider.h
//  MainAndMeios7
//
//  Created by Vladislav Zozulyak on 29.10.14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServiceProvider.h"

@interface MMServiceProvider : ServiceProvider

- (id) init;

@end
