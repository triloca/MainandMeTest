//
//  NSString+Capitalized.h
//  TennisBattle
//
//  Created by Sasha on 6/26/14.
//  Copyright (c) 2014 uniprog. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Capitalized)

- (NSString*)stringWithCapitalizedFirstCharacter;

@end
