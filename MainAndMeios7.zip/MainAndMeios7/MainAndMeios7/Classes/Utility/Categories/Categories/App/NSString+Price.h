//
//  NSString+Price.h
//  MainAndMeios7
//
//  Created by Alexander Bukov on 1/4/15.
//  Copyright (c) 2015 Uniprog. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Price)

- (NSString*)priceString;

@end
