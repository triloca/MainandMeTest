//
//  UIImage+Common.h
//  TennisBattle
//
//  Created by Sasha on 4/19/14.
//  Copyright (c) 2014 uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Common)
- (UIImage *)normalizedImage;
-(UIImage*)rotatedUIImage;
- (UIImage *)normalizedImage2;
@end
