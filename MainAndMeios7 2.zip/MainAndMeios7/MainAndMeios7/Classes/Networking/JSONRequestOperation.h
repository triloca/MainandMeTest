//
//  JSONRequestOperation.h
//  MainAndMeios7
//
//  Created by Vladislav Zozulyak on 29.10.14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import "AFJSONRequestOperation.h"

@interface JSONRequestOperation : AFJSONRequestOperation

@property (nonatomic, copy) NSString *requestEnvelope;

@end
