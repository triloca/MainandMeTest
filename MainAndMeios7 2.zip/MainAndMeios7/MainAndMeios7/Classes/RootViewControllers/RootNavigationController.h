//
//  RootNavigationController.h
//  qwe
//
//  Created by Sasha Bukov on 4/30/12.
//  Copyright (c) 2012 Company. All rights reserved.
//


@interface RootNavigationController : UINavigationController

@end
