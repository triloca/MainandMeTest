//
//  RootNavigationController.m
//  qwe
//
//  Created by Sasha Bukov on 4/30/12.
//  Copyright (c) 2012 Company. All rights reserved.
//

#import "RootNavigationController.h"

@implementation RootNavigationController

- (void)viewDidLoad{
    [super viewDidLoad];
    
    self.navigationBarHidden = YES;
        
}
@end
