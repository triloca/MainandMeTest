//
//  AFBLoginViewController.h
//  AllComponents
//
//  Created by Sasha on 4/26/14.
//  Copyright (c) 2014 uniprog. All rights reserved.
//


@interface AFBLoginViewController : UIViewController

@end
