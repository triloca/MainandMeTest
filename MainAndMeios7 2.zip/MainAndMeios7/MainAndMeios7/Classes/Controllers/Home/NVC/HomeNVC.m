//
//  HomeNVC.m
//  MainAndMeios7
//
//  Created by Alexander Bukov on 10/19/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import "HomeNVC.h"
#import "UIViewController+ECSlidingViewController.h"


@interface HomeNVC ()

@end

@implementation HomeNVC
@end
