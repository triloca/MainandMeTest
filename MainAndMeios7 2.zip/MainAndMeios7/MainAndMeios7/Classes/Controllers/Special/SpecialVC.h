//
//  SpecialVC.h
//  MainAndMeios7
//
//  Created by Vladislav Zozulyak on 11.11.14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProximityKitManager.h"

@interface SpecialVC : UIViewController


@end
