//
//  PlacesFollowCell.h
//  MainAndMeios7
//
//  Created by Max on 11/8/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSCustomBadge.h"
#import "HighlightingTableViewCell.h"

@interface PlacesFollowCell : HighlightingTableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *arrowImageView;


@end
