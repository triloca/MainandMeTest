//
//  PlacesFollowCell.m
//  MainAndMeios7
//
//  Created by Max on 11/8/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import "PlacesFollowCell.h"

@interface PlacesFollowCell ()

@end

@implementation PlacesFollowCell


@end
