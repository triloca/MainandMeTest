//
//  RegistrationCell.h
//  MainAndMeios7
//
//  Created by Bhumi Shah on 03/11/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistrationCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UITextField *txtTitle;

@end
