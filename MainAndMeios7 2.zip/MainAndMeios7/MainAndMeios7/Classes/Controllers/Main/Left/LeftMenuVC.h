//
//  LeftMenuVC.h
//  MainAndMeios7
//
//  Created by Alexander Bukov on 10/19/14.
//  Copyright (c) 2014 Uniprog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftMenuVC : UIViewController

- (void)loadNotificationCount;

@end
