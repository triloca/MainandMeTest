//
//  NSString+Path.h
//  TennisBattle
//
//  Created by Sasha on 10/21/13.
//  Copyright (c) 2013 uniprog. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Path)

@end
