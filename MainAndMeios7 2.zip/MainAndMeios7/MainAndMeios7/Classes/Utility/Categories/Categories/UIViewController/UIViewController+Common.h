//
//  UIViewController+Common.h
//  MainAndMe
//
//  Created by Sasha on 3/11/13.
//
//

#import <UIKit/UIKit.h>

@interface UIViewController (Common)
//+ (id)loadFromXIB_Or_iPhone5_XIB;

//! For iPhone 6P
+ (id)loadFromXIBForScrrenSizes;


@end
